/*
 *  statistics.h
 *
 *  Created by aw on 11/28/09.
 *  Copyright 2009 p. All rights reserved.
 */

// flaga wkompilowywania, badz nie, wykonywania statystyki dzialania
#ifndef STATISTICS_H
#define STATISTICS_H

#define STATISTICS 1

#endif
